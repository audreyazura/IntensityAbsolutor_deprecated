#!/bin/sh
./ressources/jre11-unix/bin/java -jar IntensityAbsolutor-portable.jar
